import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class MonopolyGameWindow extends JFrame {
	 private JLabel playerNameLabel;
	    private JLabel playerIconLabel;
	    private JLabel playerMoneyLabel;
	    private JButton drawButton;
	    private JPanel cardDisplayPanel;
	    private MonopolyGame game;
	    private JPanel propertyDisplayPanel;
	    private JLabel timeLabel;
	    private long startTime;
	    private Timer timer;


    public MonopolyGameWindow(MonopolyGame game, String playerName, ImageIcon playerIcon) {
    	
    	 this.game = game;
         game.addPropertyChangeListener(evt -> {
             if ("playerMoney".equals(evt.getPropertyName())) {
                 updatePlayerMoneyDisplay();
             } else if ("propertyBought".equals(evt.getPropertyName())) {
                 addPropertyToDisplay((Property) evt.getNewValue());
             }
         });

         initializeUI(playerName, playerIcon);
         setupTimer();
     }
    

    private void setupTimer() {
        timeLabel = new JLabel("Time: 0:00", SwingConstants.RIGHT);
        timeLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add some spacing

        // Set up a panel on the right side to display the timer
        JPanel timerPanel = new JPanel(new BorderLayout());
        timerPanel.add(timeLabel, BorderLayout.NORTH);

        cardDisplayPanel.add(timerPanel); // Add to the card display panel which is on the EAST
        startTime = System.currentTimeMillis();

        timer = new Timer(1000, e -> updateTime());
        timer.start();
    }

    
    private void updateTime() {
        long elapsedMillis = System.currentTimeMillis() - startTime;
        long elapsedSeconds = TimeUnit.MILLISECONDS.toSeconds(elapsedMillis);
        long secondsDisplay = elapsedSeconds % 60;
        long elapsedMinutes = elapsedSeconds / 60;
        timeLabel.setText(String.format("Time: %d:%02d", elapsedMinutes, secondsDisplay));
    }
    
    public void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }
    
  
    
    private void addPropertyToDisplay(Property property) {
        SwingUtilities.invokeLater(() -> {
            JLabel propertyLabel = new JLabel(property.getName());
            propertyLabel.setOpaque(true);
            propertyLabel.setBackground(property.getColor());
            propertyLabel.setForeground(Color.WHITE);
            propertyLabel.setPreferredSize(new Dimension(100, 20)); // Adjust size as needed
            propertyLabel.setHorizontalAlignment(JLabel.CENTER);
            propertyDisplayPanel.add(propertyLabel);
            propertyDisplayPanel.revalidate();
            propertyDisplayPanel.repaint();
            System.out.println("Property: " + property.getName() + ", Color: " + property.getColor());
        });
    }

   
    private void initializeUI(String playerName, ImageIcon playerIcon) {
        setTitle("Monopoly Card Game - Main Window");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Bottom panel for player info, small icon, name, and money
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        playerIconLabel = new JLabel(new ImageIcon(playerIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
        playerNameLabel = new JLabel("Player: " + playerName);
        playerMoneyLabel = new JLabel("Money: $" + game.getPlayerMoney());

        bottomPanel.add(playerIconLabel);
        bottomPanel.add(playerNameLabel);
        bottomPanel.add(playerMoneyLabel);
        add(bottomPanel, BorderLayout.SOUTH);

        // Draw Card button setup
        drawButton = new JButton("Draw Card");
        drawButton.addActionListener(e -> drawCard());
        add(drawButton, BorderLayout.NORTH);

        // Card Display Panel setup, with adjusted size and no border
        cardDisplayPanel = new JPanel();
        cardDisplayPanel.setPreferredSize(new Dimension(150, 300)); // Adjust width as needed
        cardDisplayPanel.setBorder(BorderFactory.createEmptyBorder()); // Removed black line border
        add(cardDisplayPanel, BorderLayout.EAST);

        // Property Display Panel setup, with a grid layout to accommodate multiple properties
        propertyDisplayPanel = new JPanel(new GridLayout(0, 3, 5, 5)); // Adjust the rows, columns, hgap, vgap if needed
        propertyDisplayPanel.setBorder(BorderFactory.createTitledBorder("Owned Properties"));
        add(propertyDisplayPanel, BorderLayout.CENTER);

        setVisible(true);
    }
    

    private void drawCommunityChestCard() {
        CommunityChestCard chestCard = CommunityChestCard.getRandomCard();
        chestCard.executeAction(game);
    }

    private void drawChanceCard() {
        ChanceCard chanceCard = ChanceCard.getRandomCard(game);
        chanceCard.executeAction(game);
    }
    
    private void drawCard() {
        Random random = new Random();
        int cardType = random.nextInt(3); // Now includes 0, 1, or 2 for three types of cards

        switch (cardType) {
            case 0:
                drawPropertyCard();
                break;
            case 1:
                drawCommunityChestCard();
                break;
            case 2:
                drawChanceCard();
                break;
            default:
                System.out.println("Unexpected value: " + cardType);
        }
    }

    private void drawPropertyCard() {
        Property drawnProperty = game.drawProperty();
        if (drawnProperty != null) {
            // Logic to handle the drawn property, like prompting the user to buy it
        } else {
            JOptionPane.showMessageDialog(this, "No more properties to draw.");
        }
    }

    public void updatePlayerMoneyDisplay() {
        SwingUtilities.invokeLater(() -> {
            System.out.println("Your Balance is now: " + game.getPlayerMoney());
            playerMoneyLabel.setText("Money: $" + game.getPlayerMoney());
            playerMoneyLabel.revalidate();
            playerMoneyLabel.repaint();
        });
    }
}
