import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MonopolyGameGUI extends JFrame implements ActionListener, KeyListener {
    private JTextField playerNameField;
    private JLabel characterPreviewLabel;
    private JLabel instructionsLabel;
    private String[] characterIcons = {"boat.png", "car.png", "hat.png", "shoe.png", "wheelbarrow.png"};
    private int currentCharacterIndex = 0;

    public MonopolyGameGUI() {
    	
    	/*
    	MonopolyGame game = new MonopolyGame();
    	MonopolyGameWindow gameWindow = new MonopolyGameWindow(game);
    	game.setGameWindow(gameWindow);
    	gameWindow.setVisible(true);

*/
    	
        setTitle("Monopoly Card Game!");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Welcome and Instructions with Enhanced Font
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        JLabel welcomeLabel = new JLabel("Hello, welcome to the Monopoly Card Game! What is your name?");
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 18)); // Making the font bigger and bold
        topPanel.add(welcomeLabel);

        // Player Name Entry
        playerNameField = new JTextField();
        playerNameField.setMaximumSize(new Dimension(200, playerNameField.getPreferredSize().height)); // Making the text field smaller
        playerNameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        topPanel.add(playerNameField);

        add(topPanel, BorderLayout.NORTH);

        // Center Panel for Character Selection and Play Button
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // Instructions for Character Selection with Enhanced Font
        instructionsLabel = new JLabel("Select your character using left and right arrow keys");
        instructionsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        instructionsLabel.setFont(new Font("Serif", Font.BOLD, 16)); // Making the font bigger and bold
        centerPanel.add(instructionsLabel);

        // Character Preview (Placeholder for actual images)
        characterPreviewLabel = new JLabel();
        characterPreviewLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        updateCharacterPreview(); // To initially load the character icon
        centerPanel.add(characterPreviewLabel);

        // Play Game Button
        JButton playButton = new JButton("Play Game");
        playButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        playButton.addActionListener(this);
        centerPanel.add(playButton);

        add(centerPanel, BorderLayout.CENTER);

        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String playerName = playerNameField.getText().trim();
        // Ensure the icon path is correct and exists in your project
        ImageIcon playerIcon = new ImageIcon(getClass().getResource("/" + characterIcons[currentCharacterIndex]));

        // Assuming MonopolyGame is properly defined and has necessary functionality
        MonopolyGame game = new MonopolyGame();
        MonopolyGameWindow gameWindow = new MonopolyGameWindow(game, playerName, playerIcon);

        gameWindow.setVisible(true);
        dispose(); // Close the character selection window after moving to the game window
    }

    
    // Key events for character selection
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            currentCharacterIndex = (currentCharacterIndex + 1) % characterIcons.length;
            updateCharacterPreview();
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            currentCharacterIndex = (currentCharacterIndex - 1 + characterIcons.length) % characterIcons.length;
            updateCharacterPreview();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    @Override
    public void keyTyped(KeyEvent e) { }

    private void updateCharacterPreview() {
        // Assuming images are resized for better layout
        ImageIcon icon = new ImageIcon(new ImageIcon(getClass().getResource(characterIcons[currentCharacterIndex])).getImage().getScaledInstance(256, 256, Image.SCALE_DEFAULT)); // Resize to 256x256
        characterPreviewLabel.setIcon(icon);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new MonopolyGameGUI().setVisible(true));
    }
}