import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ChanceCard {
    private String message;
    private Runnable action;

    // Constructor to initialize the chance card with its message and action
    public ChanceCard(String message, Runnable action) {
        this.message = message;
        this.action = action;
    }

    // Execute the action associated with the chance card
    public void executeAction(MonopolyGame game) {
        SwingUtilities.invokeLater(() -> {
            // Show the message to the user
            ImageIcon icon = new ImageIcon(getClass().getResource("/chance.png"));
            JOptionPane.showMessageDialog(null, new JLabel(this.message, new ImageIcon(icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)), JLabel.LEFT), "Chance Card", JOptionPane.INFORMATION_MESSAGE);
            // Perform the action
            this.action.run();
        });
    }

    // Get a random chance card
    public static ChanceCard getRandomCard(MonopolyGame game) {
        List<ChanceCard> cards = new ArrayList<>();
        cards.add(new ChanceCard("Advance to \"Go\". (Collect $200).", () -> game.advanceToGo()));
        cards.add(new ChanceCard("Advance to Illinois Ave.", () -> game.advanceToProperty("Illinois Avenue")));
        cards.add(new ChanceCard("Advance to St. Charles Place.", () -> game.advanceToProperty("St. Charles Place")));
        cards.add(new ChanceCard("Bank pays you dividend of $50.", () -> game.adjustPlayerMoney(50)));
        cards.add(new ChanceCard("You drew a jail card.", () -> game.goToJail())); // Pass an empty string or a placeholder since the message is handled within the action.
        cards.add(new ChanceCard("Make general repairs on all your property: For each property you own, pay $40.", () -> game.payForRepairs(40)));
        cards.add(new ChanceCard("Pay Poor Tax of $150.", () -> game.adjustPlayerMoney(-150)));
        cards.add(new ChanceCard("Take a walk on the Boardwalk. Advance token to Boardwalk.", () -> game.advanceToProperty("Boardwalk")));
        cards.add(new ChanceCard("Get Out of Jail Free Card.", game::resetJailCardCount));

        
        Random random = new Random();
        return cards.get(random.nextInt(cards.size()));
    }
}
