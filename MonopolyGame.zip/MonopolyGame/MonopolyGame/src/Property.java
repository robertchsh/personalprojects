import java.awt.Color;

public class Property {
    private String name;
    private Color color;
    private int price;
    private boolean owned = false;

    public Property(String name, Color color, int price) {
        this.name = name;
        this.color = color;
        this.price = price;
    }
    

    // Getters and Setters
    public String getName() {
        return name;
    }

    public Color getColor() {
        return color;
    }

    public int getPrice() {
        return price;
    }

    public boolean isOwned() {
        return owned;
    }

    public void setOwned(boolean owned) {
        this.owned = owned;
    }
}