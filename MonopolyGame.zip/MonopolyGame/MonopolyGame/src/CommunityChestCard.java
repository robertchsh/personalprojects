import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class CommunityChestCard {
    private String message;
    private int moneyChange;

    public CommunityChestCard(String message, int moneyChange) {
        this.message = message;
        this.moneyChange = moneyChange;
    }

    public void executeAction(MonopolyGame game) {
        // Load the chest image
        ImageIcon chestIcon = new ImageIcon(getClass().getResource("/chest.png"));
        Image image = chestIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(image);

        // Adjust the player's money and notify change
        game.adjustPlayerMoney(moneyChange);
        // Show message dialog with the chest image
        JOptionPane.showMessageDialog(null, new JLabel(this.message + "\n Balance adjusted by: $" + moneyChange + ".", scaledIcon, JLabel.LEFT), "Community Chest", JOptionPane.INFORMATION_MESSAGE);

        // Notify the UI to update the player's money display
        game.notifyMoneyChange();
    }

    public static CommunityChestCard getRandomCard() {
        List<CommunityChestCard> cards = new ArrayList<>();
        cards.add(new CommunityChestCard("Advance to 'Go'. (Collect $200.)", 200));
        cards.add(new CommunityChestCard("Doctor's fees. Pay $100.", -100)); 
        cards.add(new CommunityChestCard("Income tax refund. Collect $20.", 20));
        cards.add(new CommunityChestCard("Life insurance matures – Collect $100.", 100));
        cards.add(new CommunityChestCard("Hospital Fees. Pay $150.", -150)); 
        cards.add(new CommunityChestCard("School fees. Pay $150.", -150)); 
        cards.add(new CommunityChestCard("Receive $25 consultancy fee.", 25));
        cards.add(new CommunityChestCard("Major car repair. Pay $1000.", -1000));
        cards.add(new CommunityChestCard("Tax credit. Recieve $400.  ", 400));
        cards.add(new CommunityChestCard("Bank error in your favour. Collect $200.", 400));
        cards.add(new CommunityChestCard("From sale of your stock you get $150.", 150));

        

        Random random = new Random();
        return cards.get(random.nextInt(cards.size()));
    }
}
