// Inside MonopolyGame.java
import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;



public class MonopolyGame extends JFrame {
    
	
	private Map<Color, Integer> winConditionSets = new HashMap<>();
	private MonopolyGameWindow gameWindow;
	private int playerMoney = 1500;
	private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    private JPanel propertiesPanel; // Panel to display owned properties
    private List<Property> properties = new ArrayList<>();
    private Map<Color, List<Property>> ownedProperties = new HashMap<>(); // This line defines ownedProperties
    private int jailCardCount = 0;
    public MonopolyGame() {
    	
    	 initializeWinConditionSets();
    	 initializeProperties();
    	 
       // My constructor code
    	
        propertiesPanel = new JPanel();
        propertiesPanel.setLayout(new FlowLayout());
        add(propertiesPanel, BorderLayout.SOUTH);
        
        
        
    }
    
    public List<Property> getProperties() {
        return properties; // For Me: Ensure this is the list of all properties in the game
    }
   

    private void initializeWinConditionSets() {
        // Example values, adjust according to your game's properties
        winConditionSets.put(Color.decode("#955438"), 2); // Dark Purple/Brown
        winConditionSets.put(Color.decode("#aae0fa"), 3); // Light Blue
        // Add other colors and their required counts for a win
    }
    
    
    public void goToJail() {
        jailCardCount++;
        String message;
        if (jailCardCount > 3) {
            message = "You've drawn the 'Go to Jail' card too many times. Game over.";
            JOptionPane.showMessageDialog(null, message);
            System.exit(0);
        } else {
            message = "Go to Jail. You have " + (3 - jailCardCount) + " remaining jail visits before you lose the game.";
            JOptionPane.showMessageDialog(null, message);
            // Optionally implement moving the player to jail here
        }
    }
    
    public int getJailCardCount() {
        return jailCardCount;
    }
    
    public void resetJailCardCount() {
        jailCardCount = 0;
        JOptionPane.showMessageDialog(null, "You've used your 'Get Out of Jail Free' card. Your jail visits counter has been reset.");
    }
    
    public void payForRepairs(int costPerProperty) {
        int totalCost = ownedProperties.values().stream()
                              .flatMap(List::stream) // Flatten the list of properties
                              .mapToInt(p -> costPerProperty) // Calculate cost for each property
                              .sum(); // Sum up the total cost

        adjustPlayerMoney(-totalCost); // Deduct the total cost from player money

        JOptionPane.showMessageDialog(null, "Paid $" + totalCost + " for general repairs on all your properties.", "General Repairs", JOptionPane.INFORMATION_MESSAGE);
        notifyMoneyChange(); // Notify to update the player's money display
    }
    
    
    public void advanceToGo() {
        adjustPlayerMoney(200);
        System.out.println("Advanced to Go! Collected $200.");
    }
    
    
    public void advanceToProperty(String propertyName) {
        Property targetProperty = properties.stream()
                                             .filter(property -> property.getName().equals(propertyName))
                                             .findFirst()
                                             .orElse(null);

        if (targetProperty != null) {
            // Check if the property is already owned
            if (!targetProperty.isOwned()) {
                // Display property information
                ImageIcon propertyIcon = new ImageIcon(getClass().getResource("/property.png"));
                JOptionPane.showMessageDialog(null, new JLabel(new ImageIcon(propertyIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH))), "You've landed on " + targetProperty.getName(), JOptionPane.INFORMATION_MESSAGE);

                // Ask the player if they want to buy the property
                int response = JOptionPane.showConfirmDialog(null, "Do you want to buy " + targetProperty.getName() + " for $" + targetProperty.getPrice() + "?", "Buy Property", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    buyProperty(targetProperty);
                }
            } else {
                JOptionPane.showMessageDialog(null, targetProperty.getName() + " is already owned.", "Property Owned", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Property not found: " + propertyName, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void adjustPlayerMoney(int amount) {
        int oldMoney = this.playerMoney;
        this.playerMoney += amount; // Adjust the player's money.
        pcs.firePropertyChange("playerMoney", oldMoney, this.playerMoney); // Notify listeners.
        
        if (this.playerMoney < 0) {
            // Player has run out of money
            JOptionPane.showMessageDialog(null, "Sorry, you ran out of money... Better luck next time! Game over.");
            System.exit(0); // or any other mechanism to end or reset the game
        }
    }
    
    public void setGameWindow(MonopolyGameWindow gameWindow) {
        this.gameWindow = gameWindow;
    }
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        pcs.removePropertyChangeListener(listener);
    }
    
    public void notifyMoneyChange() {
        // System.out.println("notifyMoneyChange called"); // Debugging line
        if (gameWindow != null) {
            gameWindow.updatePlayerMoneyDisplay();
        }
    }

    
    public Property drawProperty() {
        Random random = new Random();
        Property drawnProperty = properties.get(random.nextInt(properties.size()));

        // Display property information
        ImageIcon propertyIcon = new ImageIcon(getClass().getResource("/property.png"));
        if (propertyIcon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(null, "Property image not found", "Image Error", JOptionPane.ERROR_MESSAGE);
            return drawnProperty; // Exit early because the image was not found
        }

        // Use HTML to style the property name with its color (I am new at this)
        String colorHex = String.format("#%02x%02x%02x", drawnProperty.getColor().getRed(),
                                        drawnProperty.getColor().getGreen(),
                                        drawnProperty.getColor().getBlue());
        String message = "<html>Do you want to buy <span style='color:" + colorHex + ";'>" + drawnProperty.getName() +
                         "</span> for $" + drawnProperty.getPrice() + "?</html>";

        int response = JOptionPane.showConfirmDialog(null, new JLabel(message), "Buy Property", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, new ImageIcon(propertyIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));

        if (response == JOptionPane.YES_OPTION) {
            buyProperty(drawnProperty);
        }

        return drawnProperty;
    }


    public void buyProperty(Property property) {
        if (playerMoney >= property.getPrice() && !property.isOwned()) {
            int oldMoney = playerMoney;
            playerMoney -= property.getPrice();
            property.setOwned(true);
            pcs.firePropertyChange("playerMoney", oldMoney, playerMoney);
            pcs.firePropertyChange("propertyBought", null, property); // Notify about the bought property
            // Add the property to ownedProperties map for win condition check
            ownedProperties.computeIfAbsent(property.getColor(), k -> new ArrayList<>()).add(property);
            checkWinCondition(); // Call to check if winning condition is met

            // Use HTML to style the property name with its color in the JOptionPane message
            String colorHex = String.format("#%02x%02x%02x", property.getColor().getRed(),
                                            property.getColor().getGreen(),
                                            property.getColor().getBlue());
            JOptionPane.showMessageDialog(null, "<html>You have bought <span style='color:" + colorHex + ";'>" + property.getName() + "</span>!</html>", "Property Purchased", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "You cannot afford this property, or you have already purchased it.", "Transaction Failed", JOptionPane.ERROR_MESSAGE);
        }
    }


//    private void updatePropertiesPanel(Property property) {
//        // Add a visual representation of the property to the propertiesPanel
//        JPanel propertyIcon = new JPanel();
//        propertyIcon.setBackground(property.getColor());
//        propertyIcon.setPreferredSize(new Dimension(20, 20)); // Example size
//        propertiesPanel.add(propertyIcon);
//        propertiesPanel.revalidate();
//        propertiesPanel.repaint();
//    }
    
    private void initializeProperties() {
        // Brown (or Dark Purple) properties
        properties.add(new Property("Mediterranean Avenue", Color.decode("#955438"), 60));
        properties.add(new Property("Baltic Avenue", Color.decode("#955438"), 60));

        // Light Blue properties
        properties.add(new Property("Oriental Avenue", Color.decode("#aae0fa"), 100));
        properties.add(new Property("Vermont Avenue", Color.decode("#aae0fa"), 100));
        properties.add(new Property("Connecticut Avenue", Color.decode("#aae0fa"), 120));

        // Magenta properties
        properties.add(new Property("St. Charles Place", Color.decode("#d93a96"), 140));
        properties.add(new Property("States Avenue", Color.decode("#d93a96"), 140));
        properties.add(new Property("Virginia Avenue", Color.decode("#d93a96"), 160));

        // Orange properties
        properties.add(new Property("St. James Place", Color.decode("#f7941d"), 180));
        properties.add(new Property("Tennessee Avenue", Color.decode("#f7941d"), 180));
        properties.add(new Property("New York Avenue", Color.decode("#f7941d"), 200));

        // Red properties
        properties.add(new Property("Kentucky Avenue", Color.decode("#ed1b24"), 220));
        properties.add(new Property("Indiana Avenue", Color.decode("#ed1b24"), 220));
        properties.add(new Property("Illinois Avenue", Color.decode("#ed1b24"), 240));

        // Yellow properties
        properties.add(new Property("Atlantic Avenue", Color.decode("#fccf05"), 260));
        properties.add(new Property("Ventnor Avenue", Color.decode("#fccf05"), 260));
        properties.add(new Property("Marvin Gardens", Color.decode("#fccf05"), 280));

        // Green properties
        properties.add(new Property("Pacific Avenue", Color.decode("#1fb25a"), 300));
        properties.add(new Property("North Carolina Avenue", Color.decode("#1fb25a"), 300));
        properties.add(new Property("Pennsylvania Avenue", Color.decode("#1fb25a"), 320));

        // Dark Blue properties
        properties.add(new Property("Park Place", Color.decode("#0072bb"), 350));
        properties.add(new Property("Boardwalk", Color.decode("#0072bb"), 400));

        // Initialize ownedProperties with empty lists for each color
        for (Property property : properties) {
            ownedProperties.putIfAbsent(property.getColor(), new ArrayList<>());
        }
    }


    private void checkWinCondition() {
        Map<Color, Integer> colorToWinningCount = new HashMap<>();
        
        colorToWinningCount.put(Color.decode("#955438"), 2); // Dark Purple/Brown (Mediterranean and Baltic Avenues)
        colorToWinningCount.put(Color.decode("#aae0fa"), 3); // Light Blue (Oriental, Vermont, Connecticut)
        colorToWinningCount.put(Color.decode("#d93a96"), 3); // Magenta (St. Charles Place, States, Virginia)
        colorToWinningCount.put(Color.decode("#f7941d"), 3); // Orange (St. James Place, Tennessee, New York)
        colorToWinningCount.put(Color.decode("#ed1b24"), 3); // Red (Kentucky, Indiana, Illinois)
        colorToWinningCount.put(Color.decode("#fef200"), 3); // Yellow (Atlantic, Ventnor, Marvin Gardens)
        colorToWinningCount.put(Color.decode("#1fb25a"), 3); // Green (Pacific, North Carolina, Pennsylvania)
        colorToWinningCount.put(Color.decode("#0072bb"), 2); // Dark Blue (Park Place, Boardwalk)

        for (Map.Entry<Color, Integer> entry : colorToWinningCount.entrySet()) {
            Color color = entry.getKey();
            Integer requiredCount = entry.getValue();
            List<Property> ownedPropertiesOfColor = ownedProperties.get(color);

            if (ownedPropertiesOfColor != null && ownedPropertiesOfColor.size() == requiredCount) {
                // Win condition met
                JOptionPane.showMessageDialog(null, "Congratulations, you've collected all properties of " + colorToString(color) + " color set! You win!");
                System.exit(0); // or any other mechanism to end or reset the game
                return; // Exit the method to avoid further processing
            }
        }
    }
    
    
    private String colorToString(Color color) {
        if (Color.decode("#955438").equals(color)) {
            return "Brown (Mediterranean and Baltic Avenues)";
        } else if (Color.decode("#aae0fa").equals(color)) {
            return "Light Blue (Oriental, Vermont, and Connecticut Avenues)";
        } else if (Color.decode("#d93a96").equals(color)) {
            return "Pink (St. Charles Place, States Avenue, and Virginia Avenue)";
        } else if (Color.decode("#f7941d").equals(color)) {
            return "Orange (St. James Place, Tennessee Avenue, and New York Avenue)";
        } else if (Color.decode("#ed1b24").equals(color)) {
            return "Red (Kentucky Avenue, Indiana Avenue, and Illinois Avenue)";
        } else if (Color.decode("#fef200").equals(color)) {
            return "Yellow (Atlantic Avenue, Ventnor Avenue, and Marvin Gardens)";
        } else if (Color.decode("#1fb25a").equals(color)) {
            return "Green (Pacific Avenue, North Carolina Avenue, and Pennsylvania Avenue)";
        } else if (Color.decode("#0072bb").equals(color)) {
            return "Dark Blue (Park Place and Boardwalk)";
            
            
            // will probably not be implemented...
        } else if (Color.decode("#ffffff").equals(color)) {
            return "Railroads";
        } else if (Color.decode("#000000").equals(color)) {
            return "Utilities";
        }
        // Default case if the color doesn't match any of the above
        return "an unknown set";
    }


    public int getPlayerMoney() {
        return playerMoney;
    }
    

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new MonopolyGame().setVisible(true));
    }
}

