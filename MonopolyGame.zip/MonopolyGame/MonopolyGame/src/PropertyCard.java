import java.awt.Color;
import java.awt.Image;
import javax.swing.*;

public class PropertyCard {
    private String name;
    private int price;
    private String imagePath;
    private String description;

    public PropertyCard(String name, int price, String description, String imagePath) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.imagePath = imagePath; // No need to prepend a forward slash
    }
    
    
    public void executeAction(MonopolyGame game) {
        // Load the property icon using getResource, which looks for resources in the classpath
        ImageIcon propertyIcon = new ImageIcon(getClass().getResource("/property.png"));
        if (propertyIcon == null || propertyIcon.getIconWidth() == -1) {
            // Handle the case where the image is not found or cannot be loaded
            JOptionPane.showMessageDialog(null, "Property image not found: " + imagePath, "Image Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Display property details with the image
        JOptionPane.showMessageDialog(null, new JLabel(propertyIcon), description, JOptionPane.INFORMATION_MESSAGE);

        // Prompt user to buy the property
        int response = JOptionPane.showConfirmDialog(null, "Do you want to buy " + name + " for $" + price + "?", "Buy Property", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            // Find the matching property in the game's list of properties
            Property propertyToBuy = game.getProperties().stream()
                .filter(p -> p.getName().equals(name) && p.getColor().equals(determinePropertyColor()))
                .findFirst()
                .orElse(null);
            

            if (propertyToBuy != null && !propertyToBuy.isOwned()) {
                game.buyProperty(propertyToBuy);
            } else {
                // If the property is not found or already owned, handle the error accordingly
                JOptionPane.showMessageDialog(null, "Property not available for purchase.", "Purchase Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private Color determinePropertyColor() {
        // Determine the color based on the property's name
        // I can create a map or use an if-else/switch statement to associate property names with their colors
        switch (name) {
            case "Boardwalk":
                return Color.BLUE;
            case "Park Place":
                return Color.BLUE;
            // ... other cases for different properties
            default:
                return Color.GRAY; // Default case, I might want to adjust this
        }
    }
}
